README.txt

This example loads a local data file as if it were a Javascript library file.
This trick enables us to read the local data file without needing to run
any sort of web server.

Installation
Extract the zip file onto your system. You'll also need a web browser.

Running
Open your web browser, then open the local_example.html file.

  Instructions for specific browsers:
  
  * Internet Explorer
    a) File / Open...   menu option
    b) Press [Browse] and navigate to the local_example.html file
    
  * Firefox, Safari
    a)File / Open File...  menu option
    b) Then navigate to the local_example.html file
    
  * Chrome: Doesn't seem to offer a file open option. 
    You can enter a file url specification of 
    file:///C:/something / something /local_example/local_example.html
    but that's not so convenient.

You should then see the Timeline displayed in your browser.
You will need access to the internet to enable your browser to load the 
Timeline library from the MIT server.

Problems and Questions
Please use the mailing list for help:
http://groups.google.com/group/simile-widgets/

LICENSE
This software is open source with a permissive license.
See http://simile-widgets.googlecode.com
for license details and more information.